import imageio

img = imageio.imread(f'output/images/emoji_10.png')
print(img)
